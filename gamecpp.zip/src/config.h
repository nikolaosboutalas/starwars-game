#pragma once

#define WINDOW_HEIGHT 700
#define WINDOW_WIDTH 500

#define ASSET_PATH "assets/"